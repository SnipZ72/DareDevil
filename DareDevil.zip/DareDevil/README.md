# DareDevil
# List of git commands
git init -- init git in folder (creates .git)<br />
git add . -- adds file to commit<br />
git commit -m "msg" -- commits files to local repo<br />
git remote add origin https://github.com/SnipZ72/DareDevil/ -- adds repo to origin var<br />
git pull origin master -- syncs changes from origin repo to local repo branch master<br />
git push origin master -- pushes changes in local repo to origin repo<br />
